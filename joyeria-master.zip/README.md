joyeria
=======

carrusel: http://it-artdata.com/2012/09/cloud-carousel-a-3d-carousel-in-javascript/
Pensaba consumir un archivo JSON para la cuestion de las secciones, subsecciones y detalle de las joyas.
